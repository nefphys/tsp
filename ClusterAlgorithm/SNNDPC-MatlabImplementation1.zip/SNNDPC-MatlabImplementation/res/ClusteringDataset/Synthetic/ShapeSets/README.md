Third column is the label.

Aggregation
N=788, k=7, D=2

Compound
N=399, k=6, D=2

Pathbased
N=300, k=3, D=2

Spiral
N=312, k=3, D=2

D31
N=3100, k=31, D=2

R15
N=600, k=15, D=2

Jain
N=373, k=2, D=2

Flame
N=240, k=2, D=2
