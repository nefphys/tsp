cluster_dp
==========

Clustering by fast search and find of density peaks

## Paper related

The related paper can be found here:

http://www.sciencemag.org/content/344/6191/1492.short

## How to use

Just download the '.m' file. There are more details in the file.